<?php
// Configurações do banco de dados
$host = "localhost"; // Host do banco de dados
$usuario = "root"; // Nome de usuário do banco de dados
$senha = ""; // Senha do banco de dados
$banco = "abrigogatos"; // Nome do banco de dados

// Inicializa as variáveis
$email = "";
$pass = "";
$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["email"])) {
        $email = $_POST["email"];
    }
    // Verifica se o campo 'senha' foi enviado no formulário
    if (isset($_POST["senha"])) {
        $pass = $_POST["senha"];
    }
    // Captura os dados do formulário
    $email = $_POST["email"];
    $pass = $_POST["senha"];

    // Conectando ao banco de dados
    $conexao = new mysqli($host, $usuario, $senha, $banco);

    // Verificando a conexão
    if ($conexao->connect_error) {
        die("Erro na conexão: " . $conexao->connect_error);
    }

    // Consulta SQL
    $query = "SELECT * FROM `admin` WHERE emailAdmin = '$email' AND senhaAdmin = '$pass'";

    // Executando a consulta
    $resultado = $conexao->query($query);

    // Verificando se a consulta encontrou um registro correspondente
    if ($resultado && $resultado->num_rows > 0) {
        $mensagem = "Login bem-sucedido!";
    } else {
        $mensagem = "Email ou senha incorretos.";
    }

    // Fechando a conexão com o banco de dados
    $conexao->close();
}
?>

